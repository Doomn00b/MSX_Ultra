# Intel-8254
Used Verilog to implement the Intel 8254 programmable interval timer chip.
